import { Entity } from "../interfaces/wikiResponse";

export const getImageFileName = (entity?: Entity): string | undefined => {
    const fileName = entity?.claims?.P18?.[0]?.mainsnak?.datavalue?.value;
    return typeof fileName === "string" ? fileName : undefined;
};