import { cachasheedApi } from "../api/cachasheedApi";

interface CommonsResponse {
    query: {
        pages: Record<string, { imageinfo?: { thumburl?: string }[] }>;
    };
}

export const getThumbUrl = async (fileName: string): Promise<string | undefined> => {
    const { data } = await cachasheedApi.get<CommonsResponse>(
        `https://commons.wikimedia.org/w/api.php?action=query&prop=imageinfo&iiprop=url&iiurlwidth=300&format=json&titles=${encodeURIComponent("File:" + fileName)}`
    );
    const page = Object.values(data.query.pages)[0];
    return page?.imageinfo?.[0]?.thumburl;
};